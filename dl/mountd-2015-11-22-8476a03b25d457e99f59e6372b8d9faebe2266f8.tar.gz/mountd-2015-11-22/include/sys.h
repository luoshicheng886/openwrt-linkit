#ifndef _SYS_H__
#define _SYS_H__

int system_printf(char *fmt, ...);

#endif
