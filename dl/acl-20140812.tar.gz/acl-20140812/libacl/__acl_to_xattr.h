char *__acl_to_xattr(const acl_obj *acl_obj_p, size_t *size);
